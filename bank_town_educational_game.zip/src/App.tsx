import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState, useEffect } from "react";
import { toast } from "sonner";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-blue-100 to-green-100">
      <header className="sticky top-0 z-10 bg-white/90 backdrop-blur-sm h-16 flex justify-between items-center border-b shadow-sm px-4">
        <h2 className="text-2xl font-bold text-blue-600">🏦 Bank Town</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 p-4">
        <Content />
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const loggedInUser = useQuery(api.auth.loggedInUser);
  const gameState = useQuery(api.game.getGameState);
  const initializeGameState = useMutation(api.game.initializeGameState);

  if (loggedInUser === undefined || gameState === undefined) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Authenticated>
        {gameState ? (
          gameState.gameCompleted ? (
            <CompletionScreen />
          ) : (
            <GameInterface gameState={gameState} />
          )
        ) : (
          <InitializeGame onInitialize={initializeGameState} />
        )}
      </Authenticated>
      <Unauthenticated>
        <div className="text-center py-12">
          <h1 className="text-4xl font-bold text-blue-600 mb-4">Welcome to Bank Town!</h1>
          <p className="text-xl text-gray-600 mb-8">Learn about money, banks, and smart spending</p>
          <SignInForm />
        </div>
      </Unauthenticated>
    </div>
  );
}

function InitializeGame({ onInitialize }: { onInitialize: () => Promise<any> }) {
  const [isInitializing, setIsInitializing] = useState(false);

  const handleInitialize = async () => {
    setIsInitializing(true);
    try {
      await onInitialize();
      toast.success("Welcome to Bank Town!");
    } catch (error) {
      toast.error("Failed to start game");
    }
    setIsInitializing(false);
  };

  return (
    <div className="text-center py-12">
      <h1 className="text-4xl font-bold text-blue-600 mb-4">Welcome to Bank Town!</h1>
      <p className="text-xl text-gray-600 mb-8">Ready to learn about money and banking?</p>
      <button
        onClick={handleInitialize}
        disabled={isInitializing}
        className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 transition-colors"
      >
        {isInitializing ? "Starting..." : "Start Game"}
      </button>
    </div>
  );
}

function CompletionScreen() {
  const restartGame = useMutation(api.game.restartGame);
  const [isRestarting, setIsRestarting] = useState(false);

  const handleRestart = async () => {
    setIsRestarting(true);
    try {
      await restartGame();
      toast.success("Game restarted!");
    } catch (error) {
      toast.error("Failed to restart game");
    }
    setIsRestarting(false);
  };

  return (
    <div className="text-center py-12 space-y-6">
      <div className="text-6xl mb-4">🎉</div>
      <h1 className="text-4xl font-bold text-blue-600 mb-4">Congratulations!</h1>
      <p className="text-2xl text-gray-700 mb-6">
        You learned how to save, spend, and choose wisely!
      </p>
      <div className="bg-white rounded-lg shadow-md p-6 max-w-md mx-auto">
        <h3 className="text-xl font-semibold mb-4">What You Mastered:</h3>
        <div className="space-y-2 text-left">
          <div className="flex items-center space-x-2">
            <span className="text-green-600">✅</span>
            <span>Banks keep money safe</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-green-600">✅</span>
            <span>Digital payments use debit cards</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-green-600">✅</span>
            <span>Needs help you grow</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-green-600">✅</span>
            <span>Smart spending choices</span>
          </div>
        </div>
      </div>
      <button
        onClick={handleRestart}
        disabled={isRestarting}
        className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 transition-colors"
      >
        {isRestarting ? "Restarting..." : "Play Again"}
      </button>
    </div>
  );
}

interface GameState {
  _id: string;
  cash: number;
  bankBalance: number;
  debitCardUnlocked: boolean;
  totalEarned: number;
  needsPurchased: string[];
  wantsPurchased: string[];
  currentScene: string;
  currentLevel: number;
  gameCompleted: boolean;
}

function GameInterface({ gameState }: { gameState: GameState }) {
  const changeScene = useMutation(api.game.changeScene);

  const handleSceneChange = async (scene: string) => {
    try {
      await changeScene({ scene });
    } catch (error) {
      toast.error("Failed to change scene");
    }
  };

  const getLevelName = (level: number) => {
    switch (level) {
      case 1: return "Beginner";
      case 2: return "Smart Saver";
      case 3: return "Wise Spender";
      default: return "Beginner";
    }
  };

  return (
    <div className="space-y-6">
      {/* Game Status Bar */}
      <div className="bg-white rounded-lg shadow-md p-4">
        <div className="flex justify-between items-center">
          <div className="flex space-x-6">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">₹{gameState.cash}</div>
              <div className="text-sm text-gray-500">Cash</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">₹{gameState.bankBalance}</div>
              <div className="text-sm text-gray-500">Bank</div>
            </div>
            <div className="text-center">
              <div className="text-2xl">
                {gameState.debitCardUnlocked ? "💳" : "🔒"}
              </div>
              <div className="text-sm text-gray-500">Debit Card</div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-lg font-semibold text-purple-600">
              Level {gameState.currentLevel}: {getLevelName(gameState.currentLevel)}
            </div>
            <div className="text-sm text-gray-500">
              {gameState.needsPurchased.length} needs, {gameState.wantsPurchased.length} wants
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="flex justify-center space-x-4">
        <button
          onClick={() => handleSceneChange("town")}
          className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
            gameState.currentScene === "town"
              ? "bg-blue-600 text-white"
              : "bg-white text-blue-600 border-2 border-blue-600 hover:bg-blue-50"
          }`}
        >
          🏘️ Town
        </button>
        <button
          onClick={() => handleSceneChange("bank")}
          className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
            gameState.currentScene === "bank"
              ? "bg-blue-600 text-white"
              : "bg-white text-blue-600 border-2 border-blue-600 hover:bg-blue-50"
          }`}
        >
          🏦 Bank
        </button>
        <button
          onClick={() => handleSceneChange("shop")}
          className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
            gameState.currentScene === "shop"
              ? "bg-blue-600 text-white"
              : "bg-white text-blue-600 border-2 border-blue-600 hover:bg-blue-50"
          } ${!gameState.debitCardUnlocked ? "opacity-50 cursor-not-allowed" : ""}`}
          disabled={!gameState.debitCardUnlocked}
        >
          🛍️ Shop {!gameState.debitCardUnlocked && "(Locked)"}
        </button>
      </div>

      {/* Scene Content */}
      <div className="bg-white rounded-lg shadow-md p-6 min-h-96">
        {gameState.currentScene === "town" && <TownScene gameState={gameState} />}
        {gameState.currentScene === "bank" && <BankScene gameState={gameState} />}
        {gameState.currentScene === "shop" && <ShopScene gameState={gameState} />}
      </div>
    </div>
  );
}

function TownScene({ gameState }: { gameState: GameState }) {
  const earnMoney = useMutation(api.game.earnMoney);
  const [isWorking, setIsWorking] = useState(false);

  const jobs = [
    { name: "Walk Dogs", pay: 30, emoji: "🐕", time: 2000 },
    { name: "Deliver Papers", pay: 50, emoji: "📰", time: 3000 },
    { name: "Help Neighbors", pay: 70, emoji: "🏠", time: 4000 },
  ];

  const handleWork = async (job: typeof jobs[0]) => {
    if (isWorking) return;
    
    setIsWorking(true);
    toast.info(`Working: ${job.name}...`);
    
    setTimeout(async () => {
      try {
        await earnMoney({ amount: job.pay });
        toast.success(`Earned ₹${job.pay}! Work helps you earn money.`);
      } catch (error) {
        toast.error("Failed to earn money");
      }
      setIsWorking(false);
    }, job.time);
  };

  return (
    <div className="text-center space-y-6">
      <h2 className="text-3xl font-bold text-gray-800">Welcome to Town! 🏘️</h2>
      <p className="text-lg text-gray-600">Work jobs to earn money</p>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
        {jobs.map((job, index) => (
          <div key={index} className="border-2 border-gray-200 rounded-lg p-6 hover:border-blue-300 transition-colors">
            <div className="text-4xl mb-2">{job.emoji}</div>
            <h3 className="text-xl font-semibold mb-2">{job.name}</h3>
            <div className="text-2xl font-bold text-green-600 mb-4">₹{job.pay}</div>
            <button
              onClick={() => handleWork(job)}
              disabled={isWorking}
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isWorking ? "Working..." : "Start Job"}
            </button>
          </div>
        ))}
      </div>

      {gameState.cash > 0 && (
        <div className="mt-8 p-4 bg-yellow-50 border-2 border-yellow-200 rounded-lg">
          <p className="text-lg font-semibold text-yellow-800">
            💡 You have ₹{gameState.cash} cash! Banks keep money safe.
          </p>
        </div>
      )}
    </div>
  );
}

function BankScene({ gameState }: { gameState: GameState }) {
  const depositMoney = useMutation(api.game.depositMoney);
  const [depositAmount, setDepositAmount] = useState("");

  const handleDeposit = async () => {
    const amount = parseInt(depositAmount);
    if (isNaN(amount) || amount <= 0 || amount > gameState.cash) {
      toast.error("Invalid deposit amount");
      return;
    }

    try {
      await depositMoney({ amount });
      toast.success(`Deposited ₹${amount}! Saved money grows slowly.`);
      setDepositAmount("");
      
      if (!gameState.debitCardUnlocked && gameState.bankBalance + amount >= 150) {
        toast.success("🎉 Debit card unlocked! Digital payments use debit cards.");
      }
      
      if (gameState.currentLevel === 1 && gameState.bankBalance + amount >= 150) {
        toast.success("🎉 Level up! You're now a Smart Saver!");
      }
    } catch (error) {
      toast.error("Failed to deposit money");
    }
  };

  return (
    <div className="text-center space-y-6">
      <h2 className="text-3xl font-bold text-gray-800">Bank of Town 🏦</h2>
      <p className="text-lg text-gray-600">Keep your money safe and earn a debit card</p>

      <div className="max-w-md mx-auto space-y-6">
        <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4">Your Account</h3>
          <div className="text-3xl font-bold text-blue-600 mb-2">₹{gameState.bankBalance}</div>
          <div className="text-gray-600">Current Balance</div>
        </div>

        {gameState.cash > 0 && (
          <div className="bg-white border-2 border-gray-200 rounded-lg p-6">
            <h3 className="text-xl font-semibold mb-4">Make a Deposit</h3>
            <div className="space-y-4">
              <div>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  placeholder="Amount to deposit"
                  max={gameState.cash}
                  min="1"
                  className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none"
                />
                <div className="text-sm text-gray-500 mt-1">
                  Available cash: ₹{gameState.cash}
                </div>
              </div>
              <button
                onClick={handleDeposit}
                className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Deposit Money
              </button>
            </div>
          </div>
        )}

        <div className="bg-gray-50 border-2 border-gray-200 rounded-lg p-6">
          <h3 className="text-xl font-semibold mb-4">Debit Card Status</h3>
          {gameState.debitCardUnlocked ? (
            <div className="text-green-600">
              <div className="text-4xl mb-2">💳</div>
              <div className="font-semibold">Card Active!</div>
              <div className="text-sm">You can now shop with your card</div>
            </div>
          ) : (
            <div className="text-gray-600">
              <div className="text-4xl mb-2">🔒</div>
              <div className="font-semibold">Card Locked</div>
              <div className="text-sm">Deposit ₹150 to unlock your debit card</div>
              <div className="text-xs mt-2">
                Progress: ₹{gameState.bankBalance}/150
              </div>
            </div>
          )}
        </div>

        <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-4 text-center">
          <p className="text-sm text-blue-700">
            💡 Did you know? A loan is money you borrow from a bank and must pay back later.
          </p>
        </div>
      </div>
    </div>
  );
}

function ShopScene({ gameState }: { gameState: GameState }) {
  const purchaseItem = useMutation(api.game.purchaseItem);
  const [showPinModal, setShowPinModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [pin, setPin] = useState("");

  const items = [
    // Needs
    { name: "Healthy Lunch", cost: 50, emoji: "🥗", isNeed: true },
    { name: "School Supplies", cost: 80, emoji: "📚", isNeed: true },
    { name: "Winter Coat", cost: 200, emoji: "🧥", isNeed: true },
    // Wants
    { name: "Video Game", cost: 120, emoji: "🎮", isNeed: false },
    { name: "Candy", cost: 20, emoji: "🍭", isNeed: false },
    { name: "Toy Robot", cost: 150, emoji: "🤖", isNeed: false },
  ];

  const handlePurchaseClick = (item: typeof items[0]) => {
    if (gameState.bankBalance < item.cost) {
      toast.error("Not enough money in your bank account!");
      return;
    }

    const alreadyPurchased = item.isNeed 
      ? gameState.needsPurchased.includes(item.name)
      : gameState.wantsPurchased.includes(item.name);

    if (alreadyPurchased) {
      toast.error("You already bought this item!");
      return;
    }

    setSelectedItem(item);
    setShowPinModal(true);
    setPin("");
  };

  const handlePinSubmit = async () => {
    if (!selectedItem) return;

    try {
      await purchaseItem({ 
        item: selectedItem.name, 
        cost: selectedItem.cost, 
        isNeed: selectedItem.isNeed,
        pin: pin
      });
      
      const category = selectedItem.isNeed ? "need" : "want";
      const message = selectedItem.isNeed 
        ? `Bought ${selectedItem.name}! Needs help you grow.`
        : `Bought ${selectedItem.name}! Smart spending choice.`;
      
      toast.success(message);
      
      if (gameState.currentLevel === 2 && selectedItem.isNeed && gameState.needsPurchased.length + 1 >= 2) {
        toast.success("🎉 Level up! You're now a Wise Spender!");
      }
      
      setShowPinModal(false);
      setSelectedItem(null);
      setPin("");
    } catch (error: any) {
      toast.error(error.message || "Failed to purchase item");
      if (error.message?.includes("PIN")) {
        setPin("");
      }
    }
  };

  if (!gameState.debitCardUnlocked) {
    return (
      <div className="text-center space-y-6">
        <h2 className="text-3xl font-bold text-gray-800">Town Shop 🛍️</h2>
        <div className="text-6xl">🔒</div>
        <p className="text-xl text-gray-600">
          You need a debit card to shop here!
        </p>
        <p className="text-lg text-gray-500">
          Visit the bank and deposit ₹150 to unlock your card.
        </p>
      </div>
    );
  }

  const needs = items.filter(item => item.isNeed);
  const wants = items.filter(item => !item.isNeed);

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-800">Town Shop 🛍️</h2>
        <p className="text-lg text-gray-600">Use your debit card to buy things</p>
        <div className="text-sm text-gray-500 mt-2">
          Bank Balance: ₹{gameState.bankBalance}
        </div>
      </div>

      {/* Needs Section */}
      <div>
        <h3 className="text-2xl font-bold text-green-600 mb-4">✅ Needs (Important)</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {needs.map((item, index) => {
            const purchased = gameState.needsPurchased.includes(item.name);
            const canAfford = gameState.bankBalance >= item.cost;
            
            return (
              <div key={index} className={`border-2 rounded-lg p-4 ${
                purchased ? "border-green-300 bg-green-50" : "border-green-200"
              }`}>
                <div className="text-3xl mb-2">{item.emoji}</div>
                <h4 className="font-semibold mb-2">{item.name}</h4>
                <div className="text-xl font-bold text-green-600 mb-3">₹{item.cost}</div>
                {purchased ? (
                  <div className="text-green-600 font-semibold">✅ Purchased</div>
                ) : (
                  <button
                    onClick={() => handlePurchaseClick(item)}
                    disabled={!canAfford}
                    className={`w-full py-2 px-4 rounded-lg font-semibold transition-colors ${
                      canAfford
                        ? "bg-green-600 text-white hover:bg-green-700"
                        : "bg-gray-300 text-gray-500 cursor-not-allowed"
                    }`}
                  >
                    {canAfford ? "Buy Now" : "Can't Afford"}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Wants Section */}
      <div>
        <h3 className="text-2xl font-bold text-purple-600 mb-4">🎯 Wants (Fun)</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {wants.map((item, index) => {
            const purchased = gameState.wantsPurchased.includes(item.name);
            const canAfford = gameState.bankBalance >= item.cost;
            
            return (
              <div key={index} className={`border-2 rounded-lg p-4 ${
                purchased ? "border-purple-300 bg-purple-50" : "border-purple-200"
              }`}>
                <div className="text-3xl mb-2">{item.emoji}</div>
                <h4 className="font-semibold mb-2">{item.name}</h4>
                <div className="text-xl font-bold text-purple-600 mb-3">₹{item.cost}</div>
                {purchased ? (
                  <div className="text-purple-600 font-semibold">✅ Purchased</div>
                ) : (
                  <button
                    onClick={() => handlePurchaseClick(item)}
                    disabled={!canAfford}
                    className={`w-full py-2 px-4 rounded-lg font-semibold transition-colors ${
                      canAfford
                        ? "bg-purple-600 text-white hover:bg-purple-700"
                        : "bg-gray-300 text-gray-500 cursor-not-allowed"
                    }`}
                  >
                    {canAfford ? "Buy Now" : "Can't Afford"}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Progress Summary */}
      {(gameState.needsPurchased.length > 0 || gameState.wantsPurchased.length > 0) && (
        <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6 text-center">
          <h3 className="text-xl font-semibold mb-2">Your Purchases</h3>
          <div className="flex justify-center space-x-8">
            <div>
              <div className="text-2xl font-bold text-green-600">{gameState.needsPurchased.length}</div>
              <div className="text-sm text-gray-600">Needs Bought</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">{gameState.wantsPurchased.length}</div>
              <div className="text-sm text-gray-600">Wants Bought</div>
            </div>
          </div>
        </div>
      )}

      {/* PIN Modal */}
      {showPinModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
            <h3 className="text-xl font-semibold mb-4 text-center">Enter Your PIN</h3>
            <p className="text-sm text-gray-600 mb-4 text-center">
              Use PIN: 1234 (Never share your real PIN!)
            </p>
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Enter PIN"
              maxLength={4}
              className="w-full px-4 py-2 border-2 border-gray-200 rounded-lg focus:border-blue-500 focus:outline-none text-center text-2xl tracking-widest mb-4"
            />
            <div className="flex space-x-3">
              <button
                onClick={() => {
                  setShowPinModal(false);
                  setSelectedItem(null);
                  setPin("");
                }}
                className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-lg font-semibold hover:bg-gray-400 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handlePinSubmit}
                disabled={pin.length !== 4}
                className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg font-semibold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Pay
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
