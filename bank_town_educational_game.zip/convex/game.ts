import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getGameState = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const gameState = await ctx.db
      .query("gameState")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!gameState) {
      return null;
    }

    // Handle migration for existing data
    return {
      ...gameState,
      currentLevel: gameState.currentLevel ?? 1,
      gameCompleted: gameState.gameCompleted ?? false,
    };
  },
});

export const initializeGameState = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const existingState = await ctx.db
      .query("gameState")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (existingState) {
      return existingState;
    }

    const newGameId = await ctx.db.insert("gameState", {
      userId,
      cash: 0,
      bankBalance: 0,
      debitCardUnlocked: false,
      totalEarned: 0,
      needsPurchased: [],
      wantsPurchased: [],
      currentScene: "town",
      currentLevel: 1,
      gameCompleted: false,
    });

    return await ctx.db.get(newGameId);
  },
});

export const earnMoney = mutation({
  args: { amount: v.number() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const gameState = await ctx.db
      .query("gameState")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!gameState) {
      throw new Error("Game state not found");
    }

    await ctx.db.patch(gameState._id, {
      cash: gameState.cash + args.amount,
      totalEarned: gameState.totalEarned + args.amount,
    });

    await ctx.db.insert("gameActions", {
      userId,
      action: "earn",
      amount: args.amount,
      timestamp: Date.now(),
    });
  },
});

export const depositMoney = mutation({
  args: { amount: v.number() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const gameState = await ctx.db
      .query("gameState")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!gameState) {
      throw new Error("Game state not found");
    }

    if (gameState.cash < args.amount) {
      throw new Error("Not enough cash");
    }

    const newBankBalance = gameState.bankBalance + args.amount;
    const shouldUnlockCard = !gameState.debitCardUnlocked && newBankBalance >= 150;
    
    // Level progression
    let newLevel = gameState.currentLevel ?? 1;
    if (newBankBalance >= 150 && newLevel === 1) {
      newLevel = 2;
    }

    await ctx.db.patch(gameState._id, {
      cash: gameState.cash - args.amount,
      bankBalance: newBankBalance,
      debitCardUnlocked: shouldUnlockCard || gameState.debitCardUnlocked,
      currentLevel: newLevel,
    });

    await ctx.db.insert("gameActions", {
      userId,
      action: "deposit",
      amount: args.amount,
      timestamp: Date.now(),
    });
  },
});

export const purchaseItem = mutation({
  args: { 
    item: v.string(), 
    cost: v.number(), 
    isNeed: v.boolean(),
    pin: v.string()
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    // Simple PIN check for safety education
    if (args.pin !== "1234") {
      throw new Error("Wrong PIN! Never share your PIN with anyone.");
    }

    const gameState = await ctx.db
      .query("gameState")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!gameState) {
      throw new Error("Game state not found");
    }

    if (!gameState.debitCardUnlocked) {
      throw new Error("Debit card not unlocked");
    }

    if (gameState.bankBalance < args.cost) {
      throw new Error("Insufficient bank balance");
    }

    const updatedNeeds = args.isNeed 
      ? [...gameState.needsPurchased, args.item]
      : gameState.needsPurchased;
    
    const updatedWants = !args.isNeed 
      ? [...gameState.wantsPurchased, args.item]
      : gameState.wantsPurchased;

    // Check for level 3 progression and game completion
    let newLevel = gameState.currentLevel ?? 1;
    let gameCompleted = gameState.gameCompleted ?? false;
    
    if (updatedNeeds.length >= 2 && newLevel === 2) {
      newLevel = 3;
    }
    
    if (updatedNeeds.length >= 3 && updatedWants.length >= 2) {
      gameCompleted = true;
    }

    await ctx.db.patch(gameState._id, {
      bankBalance: gameState.bankBalance - args.cost,
      needsPurchased: updatedNeeds,
      wantsPurchased: updatedWants,
      currentLevel: newLevel,
      gameCompleted,
    });

    await ctx.db.insert("gameActions", {
      userId,
      action: "purchase",
      amount: args.cost,
      item: args.item,
      timestamp: Date.now(),
    });
  },
});

export const changeScene = mutation({
  args: { scene: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const gameState = await ctx.db
      .query("gameState")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!gameState) {
      throw new Error("Game state not found");
    }

    await ctx.db.patch(gameState._id, {
      currentScene: args.scene,
    });
  },
});

export const restartGame = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Not authenticated");
    }

    const gameState = await ctx.db
      .query("gameState")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!gameState) {
      throw new Error("Game state not found");
    }

    await ctx.db.patch(gameState._id, {
      cash: 0,
      bankBalance: 0,
      debitCardUnlocked: false,
      totalEarned: 0,
      needsPurchased: [],
      wantsPurchased: [],
      currentScene: "town",
      currentLevel: 1,
      gameCompleted: false,
    });

    // Clear action history
    const actions = await ctx.db
      .query("gameActions")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();
    
    for (const action of actions) {
      await ctx.db.delete(action._id);
    }
  },
});
