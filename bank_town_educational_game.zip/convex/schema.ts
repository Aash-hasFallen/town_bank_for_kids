import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  gameState: defineTable({
    userId: v.id("users"),
    cash: v.number(),
    bankBalance: v.number(),
    debitCardUnlocked: v.boolean(),
    totalEarned: v.number(),
    needsPurchased: v.array(v.string()),
    wantsPurchased: v.array(v.string()),
    currentScene: v.string(),
    currentLevel: v.optional(v.number()),
    gameCompleted: v.optional(v.boolean()),
  }).index("by_user", ["userId"]),
  
  gameActions: defineTable({
    userId: v.id("users"),
    action: v.string(),
    amount: v.optional(v.number()),
    item: v.optional(v.string()),
    timestamp: v.number(),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
